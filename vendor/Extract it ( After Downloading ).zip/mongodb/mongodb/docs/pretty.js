$(document).ready(function() {
    $('pre code').parent().addClass('prettyprint well');
    prettyPrint();
});
